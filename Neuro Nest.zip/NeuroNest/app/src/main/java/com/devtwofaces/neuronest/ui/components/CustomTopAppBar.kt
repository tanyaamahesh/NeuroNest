package com.devtwofaces.neuronest.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.devtwofaces.neuronest.R

@Composable
fun CustomTopAppBar(
    selectedTabIndex: Int,
    onTabSelected: (Int) -> Unit,
    tabs: List<String>
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF4A3A69))
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Tabs
            Row {
                tabs.forEachIndexed { index, title ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        TextButton(
                            onClick = { onTabSelected(index) },
                            colors = ButtonDefaults.textButtonColors(
                                contentColor = if (selectedTabIndex == index) Color.White else Color.Gray
                            )
                        ) {
                            Text(
                                text = title,
                                color = if (selectedTabIndex == index) Color.White else Color.Gray,
                                fontSize = 16.sp
                            )
                        }
                        if (selectedTabIndex == index) {
                            Spacer(
                                modifier = Modifier
                                    .height(4.dp)
                                    .width(48.dp)
                                    .background(Color.White)
                            )
                        }
                    }
                }
            }

            // Icons
            Row {
                IconButton(onClick = { /* Handle settings */ }) {
                    Icon(
                        imageVector = ImageVector.vectorResource(id = R.drawable.ic_settings),
                        contentDescription = "Settings",
                        tint = Color.White
                    )
                }
                IconButton(onClick = { /* Handle info */ }) {
                    Icon(
                        imageVector = ImageVector.vectorResource(id = R.drawable.ic_info),
                        contentDescription = "Info",
                        tint = Color.White
                    )
                }
            }
        }
    }
}
