package com.devtwofaces.neuronest.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.devtwofaces.neuronest.viewmodel.MedicationViewModel

@Composable
fun AddMedicationDetailsScreen(navController: NavController, medicationName: String, viewModel: MedicationViewModel = hiltViewModel()) {
    var dosage by remember { mutableStateOf(TextFieldValue("")) }
    var unit by remember { mutableStateOf("") }
    var showUnitDropdown by remember { mutableStateOf(false) }
    val units = listOf("ML", "MG", "G", "IU", "MCG", "MEQ")
    val context = LocalContext.current;

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "Add Medication Details",
                fontSize = 24.sp,
                modifier = Modifier
                    .weight(6f)
                    .padding(bottom = 16.dp, top = 20.dp)
            )
            Spacer(modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = medicationName,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .padding(bottom = 16.dp),
            textAlign = TextAlign.Center

        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            BasicTextField(
                value = dosage,
                onValueChange = { dosage = it },
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
                    .border(BorderStroke(3.dp, color = Color(0x80C8B3E7)), shape = RoundedCornerShape(12.dp)) // Added border
                    .background(Color.White)
                    .padding(16.dp),
                decorationBox = { innerTextField ->
                    if (dosage.text.isEmpty()) {
                        Text("Enter dosage...", color = Color.Gray)
                    }
                    innerTextField()
                }
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .border(BorderStroke(3.dp, color = Color(0x80C8B3E7)), shape = RoundedCornerShape(12.dp)) // Added border
                    .background(Color.White)
                    .clickable { showUnitDropdown = true }
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(text = unit.ifEmpty { "Click..." })
                DropdownMenu(
                    expanded = showUnitDropdown,
                    onDismissRequest = { showUnitDropdown = false }
                ) {
                    units.forEach { unitOption ->
                        DropdownMenuItem(
                            onClick = {
                                unit = unitOption
                                showUnitDropdown = false
                            },
                            text = { Text(text = unitOption) }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .padding(bottom = 2.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Button(
                onClick = {
                    if (dosage.text.isEmpty() || unit.isEmpty()) {
                        Toast.makeText(context, "Dosage and unit cannot be empty", Toast.LENGTH_SHORT).show()
                    } else {
                        viewModel.addMedication(medicationName, dosage.text, unit)
                        navController.navigate("my_day") {
                            popUpTo("my_day") { inclusive = true }
                        }
                    }
                },
                modifier = Modifier
                    .padding(horizontal = 18.dp, vertical = 20.dp)
                    .height(48.dp)
                    .fillMaxSize(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A3A69)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(text = "ADD MEDICATION", color = Color.White, fontSize = 18.sp)
            }
        }

    }
}
