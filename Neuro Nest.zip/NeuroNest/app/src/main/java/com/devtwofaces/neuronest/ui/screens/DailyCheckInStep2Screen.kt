package com.devtwofaces.neuronest.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.ui.Alignment
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.res.painterResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.devtwofaces.neuronest.R
import com.devtwofaces.neuronest.viewmodel.DailyCheckInViewModel

@Composable
fun DailyCheckInStep2Screen(navController: NavController, viewModel: DailyCheckInViewModel = hiltViewModel()) {
    val scrollState = rememberScrollState()
    val symptoms by viewModel.symptoms.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { navController.navigate("daily_check_in_step1") },
                modifier = Modifier.padding(top = 10.dp)
            ) {
                Icon(painter = painterResource(id = R.drawable.ic_left), contentDescription = null)
            }
            Text(text = "Daily Check-In", fontSize = 24.sp, modifier = Modifier.padding(top = 10.dp))
            IconButton(
                onClick = { navController.navigate("daily_check_in_step3") },
                modifier = Modifier.padding(top = 10.dp)
            ) {
                Icon(painter = painterResource(id = R.drawable.ic_right), contentDescription = null)
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .fillMaxSize(),
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(top = 15.dp)
            ) {
                Text(
                    text = "What symptoms did you experience today?",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 24.dp).padding(bottom = 20.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { viewModel.toggleSymptom("HALLUCINATIONS") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (symptoms.contains("HALLUCINATIONS")) Color(0xFF8B6EB7) else Color(0xFFB39DDB)),
                    shape = RectangleShape
                ) {
                    Text(text = "HALLUCINATIONS", color = Color.White, fontSize = 18.sp)
                }

                Button(
                    onClick = { viewModel.toggleSymptom("LIGHTHEADEDNESS") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (symptoms.contains("LIGHTHEADEDNESS")) Color(0xFF8B6EB7) else Color(0xFFB39DDB)),
                    shape = RectangleShape
                ) {
                    Text(text = "LIGHTHEADEDNESS", color = Color.White, fontSize = 18.sp)
                }

                Button(
                    onClick = { viewModel.toggleSymptom("FALLING") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (symptoms.contains("FALLING")) Color(0xFF8B6EB7) else Color(0xFFB39DDB)),
                    shape = RectangleShape
                ) {
                    Text(text = "FALLING", color = Color.White, fontSize = 18.sp)
                }

                Button(
                    onClick = { viewModel.toggleSymptom("BALANCE ISSUES") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (symptoms.contains("BALANCE ISSUES")) Color(0xFF8B6EB7) else Color(0xFFB39DDB)),
                    shape = RectangleShape
                ) {
                    Text(text = "BALANCE ISSUES", color = Color.White, fontSize = 18.sp)
                }

                Button(
                    onClick = { viewModel.toggleSymptom("FREEZING OF GAIT") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (symptoms.contains("FREEZING OF GAIT")) Color(0xFF8B6EB7) else Color(0xFFB39DDB)),
                    shape = RectangleShape
                ) {
                    Text(text = "FREEZING OF GAIT", color = Color.White, fontSize = 18.sp)
                }

                Button(
                    onClick = { viewModel.toggleSymptom("SWALLOWING ISSUES") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (symptoms.contains("SWALLOWING ISSUES")) Color(0xFF8B6EB7) else Color(0xFFB39DDB)),
                    shape = RectangleShape
                ) {
                    Text(text = "SWALLOWING ISSUES", color = Color.White, fontSize = 18.sp)
                }

                Button(
                    onClick = { viewModel.toggleSymptom("DYSTONIA") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (symptoms.contains("DYSTONIA")) Color(0xFF8B6EB7) else Color(0xFFB39DDB)),
                    shape = RectangleShape
                ) {
                    Text(text = "DYSTONIA", color = Color.White, fontSize = 18.sp)
                }

                Button(
                    onClick = { viewModel.toggleSymptom("RIGIDITY") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (symptoms.contains("RIGIDITY")) Color(0xFF8B6EB7) else Color(0xFFB39DDB)),
                    shape = RectangleShape
                ) {
                    Text(text = "RIGIDITY", color = Color.White, fontSize = 18.sp)
                }

                Button(
                    onClick = { viewModel.toggleSymptom("TREMOR") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (symptoms.contains("TREMOR")) Color(0xFF8B6EB7) else Color(0xFFB39DDB)),
                    shape = RectangleShape
                ) {
                    Text(text = "TREMOR", color = Color.White, fontSize = 18.sp)
                }

                Button(
                    onClick = { viewModel.toggleSymptom("DYSKINESIA") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (symptoms.contains("DYSKINESIA")) Color(0xFF8B6EB7) else Color(0xFFB39DDB)),
                    shape = RectangleShape
                ) {
                    Text(text = "DYSKINESIA", color = Color.White, fontSize = 18.sp)
                }

                Button(
                    onClick = { viewModel.toggleSymptom("OFF PERIOD") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (symptoms.contains("OFF PERIOD")) Color(0xFF8B6EB7) else Color(0xFFB39DDB)),
                    shape = RectangleShape
                ) {
                    Text(text = "OFF PERIOD", color = Color.White, fontSize = 18.sp)
                }
            }
        }
    }
}
