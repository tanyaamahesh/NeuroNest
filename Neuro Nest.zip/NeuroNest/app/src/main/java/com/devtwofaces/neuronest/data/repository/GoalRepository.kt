package com.devtwofaces.neuronest.data.repository

import com.devtwofaces.neuronest.data.local.GoalDao
import com.devtwofaces.neuronest.data.model.Goal
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class GoalRepository @Inject constructor(
    private val goalDao: GoalDao
) {
    fun getGoals(): Flow<List<Goal>> = goalDao.getGoals()

    suspend fun addGoal(goal: Goal) = goalDao.insert(goal)

    suspend fun deleteGoal(goal: Goal) = goalDao.delete(goal)

    suspend fun updateGoal(goal: Goal) = goalDao.update(goal)
}
