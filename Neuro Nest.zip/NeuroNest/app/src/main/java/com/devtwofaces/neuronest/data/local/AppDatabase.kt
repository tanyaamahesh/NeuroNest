package com.devtwofaces.neuronest.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.devtwofaces.neuronest.data.model.*
import com.devtwofaces.neuronest.util.Converters

@Database(entities = [User::class, DailyCheckIn::class, Goal::class, Medication::class, Mood::class, Trend::class], version = 3, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dailyCheckInDao(): DailyCheckInDao
    abstract fun goalDao(): GoalDao
    abstract fun medicationDao(): MedicationDao
    abstract fun moodDao(): MoodDao
    abstract fun trendDao(): TrendDao
    abstract fun userDao(): UserDao
}

