package com.devtwofaces.neuronest.data.repository

import com.devtwofaces.neuronest.data.local.DailyCheckInDao
import com.devtwofaces.neuronest.data.local.MoodDao
import com.devtwofaces.neuronest.data.model.Mood
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.inject.Inject

class TrendRepository @Inject constructor(
    private val dailyCheckInDao: DailyCheckInDao,
    private val moodDao: MoodDao
) {
    fun getSymptoms(filter: String): Flow<List<String>> {
        val (startDate, endDate) = getDateRange(filter)
        return dailyCheckInDao.getUniqueSymptoms(startDate, endDate)
    }

    fun getFeelings(filter: String): Flow<List<Mood>> {
        val (startDate, endDate) = getDateRange(filter)
        return moodDao.getMoodsInRange(startDate, endDate)
    }

    private fun getDateRange(filter: String): Pair<String, String> {
        val calendar = Calendar.getInstance()
        val endDate = formatDate(calendar.time)

        when (filter) {
            "D" -> {
                // No changes needed, endDate is today
            }
            "W" -> {
                calendar.set(Calendar.DAY_OF_WEEK, calendar.firstDayOfWeek)
            }
            "M" -> {
                calendar.set(Calendar.DAY_OF_MONTH, 1)
            }
            "Y" -> {
                calendar.set(Calendar.DAY_OF_YEAR, 1)
            }
        }
        val startDate = formatDate(calendar.time)
        return Pair(startDate, endDate)
    }

    private fun formatDate(date: Date): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(date)
    }
}
