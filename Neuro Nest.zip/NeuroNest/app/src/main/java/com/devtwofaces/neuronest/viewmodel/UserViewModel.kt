package com.devtwofaces.neuronest.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.devtwofaces.neuronest.data.model.User
import com.devtwofaces.neuronest.data.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UserViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _user = MutableStateFlow<User?>(null)
    val user: StateFlow<User?> = _user

    init {
        viewModelScope.launch {
            _user.value = userRepository.getUser()
        }
    }

    suspend fun getUser(): User? {
        return userRepository.getUser()
    }

    fun saveUser(name: String) {
        viewModelScope.launch {
            userRepository.saveUser(User(name = name))
            _user.value = userRepository.getUser() // Update the state with the saved user
        }
    }
}


