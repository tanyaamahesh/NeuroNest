package com.devtwofaces.neuronest.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.devtwofaces.neuronest.util.Converters

@Entity(tableName = "daily_check_ins")
data class DailyCheckIn(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val intensity: String,
    @TypeConverters(Converters::class) val symptoms: List<String>,
    val importantEvents: String
)
