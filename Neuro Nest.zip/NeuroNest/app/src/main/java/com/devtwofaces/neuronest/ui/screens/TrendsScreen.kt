package com.devtwofaces.neuronest.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.devtwofaces.neuronest.R
import com.devtwofaces.neuronest.ui.components.StaticLineChart
import com.devtwofaces.neuronest.viewmodel.TrendsViewModel

@Composable
fun TrendsScreen(navController: NavController, viewModel: TrendsViewModel = hiltViewModel()) {
    val scrollState = rememberScrollState()
    val selectedFilter by viewModel.filter.collectAsState()

    val symptoms by viewModel.getSymptoms(selectedFilter).collectAsState(initial = emptyList())
    val feelings by viewModel.getFeelings(selectedFilter).collectAsState(initial = emptyList())

    val formattedSymptoms = symptoms.flatMap { it.split(",").map { s -> s.trim() } }.distinct()
    val formattedFeelings = feelings.map { feeling -> "${feeling.moodText} on ${feeling.date}" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { navController.navigateUp() }) {
                Icon(painter = painterResource(id = R.drawable.ic_left), contentDescription = null)
            }
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "Your Trends",
                fontSize = 24.sp,
                modifier = Modifier
                    .weight(6f)
                    .padding(bottom = 16.dp, top = 20.dp)
            )
            Spacer(modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Filter buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            listOf("D", "W", "M", "Y").forEach { filter ->
                Button(
                    onClick = { viewModel.setFilter(filter) },
                    colors = if (filter == selectedFilter) ButtonDefaults.buttonColors(Color(0xFF8B6EB7))
                    else ButtonDefaults.buttonColors(Color(0xFFC4B3E2))
                ) {
                    Text(text = filter)
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Static graph placeholder
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp)
                .background(Color(0xFFEDE7F6))
        ) {
            StaticLineChart()
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Display Styled Symptoms and Feelings
        StyledBulletPointList(formattedSymptoms, "Symptoms")
        Spacer(modifier = Modifier.height(16.dp))
        StyledBulletPointList(formattedFeelings, "Feeling")
    }
}

@Composable
fun StyledBulletPointList(items: List<String>, title: String) {
    Column(modifier = Modifier.padding(top = 8.dp)) {
        Text(
            text = title,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (items.isEmpty()) {
            Text("No $title recorded.", color = Color.Gray)
        } else {
            items.forEach { item ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(6.dp)
                            .height(6.dp)
                            .background(Color(0xFF4A3A69), CircleShape)
                            .align(Alignment.CenterVertically)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = item,
                        fontSize = 20.sp
                    )
                }
            }
        }
    }
}