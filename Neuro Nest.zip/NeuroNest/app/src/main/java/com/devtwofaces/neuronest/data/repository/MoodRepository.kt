package com.devtwofaces.neuronest.data.repository

import com.devtwofaces.neuronest.data.local.MoodDao
import com.devtwofaces.neuronest.data.model.Mood
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class MoodRepository @Inject constructor(
    private val moodDao: MoodDao
) {
    fun getMoods(): Flow<List<Mood>> = moodDao.getMoods()

    suspend fun getMoodForDate(date: String): Mood? = moodDao.getMoodForDate(date)

    suspend fun addOrUpdateMood(mood: Mood) {
        val existingMood = moodDao.getMoodForDate(mood.date)
        if (existingMood == null) {
            moodDao.insert(mood)
        } else {
            moodDao.update(mood.copy(id = existingMood.id))
        }
    }
}
