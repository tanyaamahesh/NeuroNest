package com.devtwofaces.neuronest.ui.components

import android.graphics.Color
import android.view.ViewGroup
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet

@Composable
fun StaticLineChart() {
    AndroidView(
        modifier = Modifier.fillMaxWidth().padding(10.dp),
        factory = { ctx ->
            LineChart(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )

                // Empty data set for static visual purpose
                val entries = listOf(Entry(0f, 0f))
                val dataSet = LineDataSet(entries, "").apply {
                    setDrawValues(false)
                    setDrawCircles(false)
                }
                this.data = LineData(dataSet)

                // Styling
                axisRight.isEnabled = false
                axisLeft.isEnabled = true
                axisLeft.setDrawGridLines(true)
                axisLeft.setDrawAxisLine(true)
                axisLeft.setDrawLabels(true)
                axisLeft.enableGridDashedLine(10f, 10f, 0f)
                axisLeft.textColor = Color.BLACK
                axisLeft.axisLineColor = Color.BLACK
                axisLeft.gridColor = Color.GRAY
                axisLeft.labelCount = 4
                axisLeft.axisMaximum = 3f
                axisLeft.axisMinimum = 0f
                axisLeft.valueFormatter = YAxisValueFormatter()

                xAxis.position = XAxis.XAxisPosition.BOTTOM
                xAxis.setDrawGridLines(true)
                xAxis.enableGridDashedLine(10f, 10f, 0f)
                xAxis.gridColor = Color.GRAY
                xAxis.axisLineColor = Color.BLACK
                xAxis.textColor = Color.BLACK
                xAxis.setDrawAxisLine(true)
                xAxis.setDrawLabels(true)
                xAxis.valueFormatter = XAxisValueFormatter()
                xAxis.labelCount = 4

                description.isEnabled = false
                legend.isEnabled = false
                setTouchEnabled(false)
                setPinchZoom(false)
            }
        }
    )
}

class XAxisValueFormatter : com.github.mikephil.charting.formatter.IndexAxisValueFormatter() {
    override fun getFormattedValue(value: Float): String {
        return when (value.toInt()) {
            0 -> "12AM"
            1 -> "6AM"
            2 -> "12PM"
            3 -> "6PM"
            else -> ""
        }
    }
}

class YAxisValueFormatter : com.github.mikephil.charting.formatter.IndexAxisValueFormatter() {
    override fun getFormattedValue(value: Float): String {
        return "${value.toInt()}h"
    }
}