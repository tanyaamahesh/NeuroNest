package com.devtwofaces.neuronest.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.devtwofaces.neuronest.R
import com.devtwofaces.neuronest.viewmodel.DailyCheckInViewModel

@Composable
fun DailyCheckInStep1Screen(navController: NavController, viewModel: DailyCheckInViewModel = hiltViewModel()) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { /* Do nothing as there is no left navigation */ },
                modifier = Modifier.padding(top = 10.dp)
            ) {
                Icon(painter = painterResource(id = R.drawable.ic_left), contentDescription = null, tint = Color.Transparent)
            }
            Text(text = "Daily Check-In", fontSize = 24.sp, modifier = Modifier.padding(top = 10.dp))
            IconButton(
                onClick = { navController.navigate("daily_check_in_step2") },
                modifier = Modifier.padding(top = 10.dp)
            ) {
                Icon(painter = painterResource(id = R.drawable.ic_right), contentDescription = null)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .fillMaxSize(),
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(top = 60.dp)
            ) {
                Text(
                    text = "What is the intensity of your symptoms today?",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 24.dp).padding(bottom = 30.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        viewModel.setIntensity("NOT PRESENT")
                        navController.navigate("daily_check_in_step2")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD1C4E9)),
                    shape = RectangleShape
                ) {
                    Text(text = "NOT PRESENT", color = Color.White, fontSize = 18.sp)
                }

                Button(
                    onClick = {
                        viewModel.setIntensity("MILD")
                        navController.navigate("daily_check_in_step2")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB39DDB)),
                    shape = RectangleShape
                ) {
                    Text(text = "MILD", color = Color.White, fontSize = 18.sp)
                }

                Button(
                    onClick = {
                        viewModel.setIntensity("MODERATE")
                        navController.navigate("daily_check_in_step2")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9575CD)),
                    shape = RectangleShape
                ) {
                    Text(text = "MODERATE", color = Color.White, fontSize = 18.sp)
                }

                Button(
                    onClick = {
                        viewModel.setIntensity("SEVERE")
                        navController.navigate("daily_check_in_step2")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp)
                        .padding(vertical = 8.dp, horizontal = 28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7E57C2)),
                    shape = RectangleShape
                ) {
                    Text(text = "SEVERE", color = Color.White, fontSize = 18.sp)
                }
            }
        }
    }
}
