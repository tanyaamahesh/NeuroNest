package com.devtwofaces.neuronest.data.repository

import com.devtwofaces.neuronest.data.local.DailyCheckInDao
import com.devtwofaces.neuronest.data.model.DailyCheckIn
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class DailyCheckInRepository @Inject constructor(private val dailyCheckInDao: DailyCheckInDao) {

    suspend fun insertOrUpdateDailyCheckIn(checkIn: DailyCheckIn) {
        val existingCheckIn = dailyCheckInDao.getCheckInByDate(checkIn.date)
        if (existingCheckIn == null) {
            dailyCheckInDao.insertDailyCheckIn(checkIn)
        } else {
            dailyCheckInDao.updateDailyCheckIn(checkIn.copy(id = existingCheckIn.id))
        }
    }

    suspend fun getDailyCheckInByDate(date: String): DailyCheckIn? {
        return dailyCheckInDao.getCheckInByDate(date)
    }
}
