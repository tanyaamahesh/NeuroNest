package com.devtwofaces.neuronest.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.luminance
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import com.devtwofaces.neuronest.ui.components.CustomTopAppBar
import com.devtwofaces.neuronest.ui.components.NamePromptDialog
import com.devtwofaces.neuronest.viewmodel.DailyCheckInViewModel
import com.devtwofaces.neuronest.viewmodel.UserViewModel
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import kotlinx.coroutines.launch

@Composable
fun MainScreen(navController: NavHostController) {
    val systemUiController = rememberSystemUiController()
    val useDarkIcons = MaterialTheme.colorScheme.primary.luminance() > 0.5f

    SideEffect {
        systemUiController.setSystemBarsColor(
            color = Color(0xFF4A3A69),
            darkIcons = useDarkIcons
        )
    }

    val viewModel: UserViewModel = hiltViewModel()
    val user by viewModel.user.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        coroutineScope.launch {
            val fetchedUser = viewModel.getUser()
            showDialog = fetchedUser == null
        }
    }

    if (user == null && !showDialog) {
        LoadingScreen()
    } else if (showDialog) {
        NamePromptDialog(
            onNameEntered = {
                viewModel.saveUser(it)
                showDialog = false
            }
        )
    } else {
        MainContent(navController)
    }
}

@Composable
fun LoadingScreen() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator()
    }
}


@Composable
fun MainContent(navController: NavHostController) {
    val tabs = listOf("my_day", "insights")
    val currentBackStack by navController.currentBackStackEntryAsState()
    val currentDestination = currentBackStack?.destination?.route ?: tabs[0]

    val showTopBar = currentDestination in tabs

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        if (showTopBar) {
            CustomTopAppBar(
                selectedTabIndex = tabs.indexOf(currentDestination),
                onTabSelected = { navController.navigate(tabs[it]) },
                tabs = listOf("My Day", "Insights")
            )
        }

        val viewModel: DailyCheckInViewModel = hiltViewModel()

        NavHost(navController = navController, startDestination = "my_day") {
            composable("my_day") { MyDayScreen(navController) }
            composable("insights") { InsightsScreen() }
            composable("add_medication") { AddMedicationScreen(navController) }
            composable("add_medication_details/{medicationName}") { backStackEntry ->
                val medicationName = backStackEntry.arguments?.getString("medicationName")
                medicationName?.let {
                    AddMedicationDetailsScreen(navController, it)
                }
            }
            composable("add_goal") { AddGoalScreen(navController) }
            composable("log_item") { LogAnItemScreen(navController) }

            composable("daily_check_in_step1") { DailyCheckInStep1Screen(navController, viewModel) }
            composable("daily_check_in_step2") { DailyCheckInStep2Screen(navController, viewModel) }
            composable("daily_check_in_step3") { DailyCheckInStep3Screen(navController, viewModel) }
            composable("trends_screen") { TrendsScreen(navController) }

        }
    }
}

@Composable
fun InsightsScreen() {
    // Placeholder for Insights screen
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text = "Insights Screen")
    }
}
