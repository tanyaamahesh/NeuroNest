package com.devtwofaces.neuronest.data.repository

import com.devtwofaces.neuronest.data.local.MedicationDao
import com.devtwofaces.neuronest.data.model.Medication
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class MedicationRepository @Inject constructor(
    private val medicationDao: MedicationDao
) {
    fun getMedications(): Flow<List<Medication>> = medicationDao.getMedications()

    suspend fun addMedication(medication: Medication) {
        medicationDao.insert(medication)
    }

    suspend fun deleteMedication(medication: Medication) {
        medicationDao.delete(medication)
    }
}

