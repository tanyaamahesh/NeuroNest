package com.devtwofaces.neuronest.viewmodel

import androidx.lifecycle.ViewModel
import com.devtwofaces.neuronest.data.model.Mood
import com.devtwofaces.neuronest.data.repository.TrendRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class TrendsViewModel @Inject constructor(
    private val trendRepository: TrendRepository
) : ViewModel() {

    private val _filter = MutableStateFlow("D")
    val filter: StateFlow<String> = _filter

    fun setFilter(newFilter: String) {
        _filter.value = newFilter
    }

    fun getSymptoms(filter: String): Flow<List<String>> {
        return trendRepository.getSymptoms(filter)
    }

    fun getFeelings(filter: String): Flow<List<Mood>> {
        return trendRepository.getFeelings(filter)
    }
}
