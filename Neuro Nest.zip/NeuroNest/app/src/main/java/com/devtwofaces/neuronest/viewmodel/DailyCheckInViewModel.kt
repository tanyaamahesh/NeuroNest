package com.devtwofaces.neuronest.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.devtwofaces.neuronest.data.model.DailyCheckIn
import com.devtwofaces.neuronest.data.repository.DailyCheckInRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

@HiltViewModel
class DailyCheckInViewModel @Inject constructor(
    private val repository: DailyCheckInRepository
) : ViewModel() {
    private val _intensity = MutableStateFlow("")
    val intensity: StateFlow<String> = _intensity

    private val _symptoms = MutableStateFlow(emptyList<String>())
    val symptoms: StateFlow<List<String>> = _symptoms

    private val _importantEvents = MutableStateFlow("")
    val importantEvents: StateFlow<String> = _importantEvents

    init {
        viewModelScope.launch {
            val checkIn = repository.getDailyCheckInByDate(getCurrentDate())
            checkIn?.let {
                _intensity.value = it.intensity
                _symptoms.value = it.symptoms
                _importantEvents.value = it.importantEvents
            }
        }
    }

    fun setIntensity(intensity: String) {
        _intensity.value = intensity
    }

    fun toggleSymptom(symptom: String) {
        _symptoms.value = _symptoms.value.toMutableList().apply {
            if (contains(symptom)) {
                remove(symptom)
            } else {
                add(symptom)
            }
        }
    }

    fun setImportantEvents(events: String) {
        _importantEvents.value = events
    }

    private fun getCurrentDate(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    fun saveCheckIn() {
        viewModelScope.launch {
            val checkIn = DailyCheckIn(
                date = getCurrentDate(),
                intensity = _intensity.value,
                symptoms = _symptoms.value,
                importantEvents = _importantEvents.value
            )
            repository.insertOrUpdateDailyCheckIn(checkIn)
        }
    }
}
