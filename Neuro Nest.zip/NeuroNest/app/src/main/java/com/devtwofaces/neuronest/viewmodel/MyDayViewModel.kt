package com.devtwofaces.neuronest.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.devtwofaces.neuronest.data.repository.MoodRepository
import com.devtwofaces.neuronest.data.model.Mood
import com.devtwofaces.neuronest.data.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MyDayViewModel @Inject constructor(
    private val moodRepository: MoodRepository,
    userRepository: UserRepository
) : ViewModel() {
    private val _moods = MutableStateFlow<List<Mood>>(emptyList())
    val moods: StateFlow<List<Mood>> = _moods

    private val _selectedMood = MutableStateFlow("")
    val selectedMood: StateFlow<String> = _selectedMood

    private val _userName = userRepository.user
        .map { it?.name ?: "NAME" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "NAME")
    val userName: StateFlow<String> = _userName

    init {
        fetchMoods()
        loadMoodForToday()
    }

    private fun fetchMoods() {
        viewModelScope.launch {
            moodRepository.getMoods().collect { listOfMoods ->
                _moods.value = listOfMoods
            }
        }
    }

    private fun loadMoodForToday() {
        viewModelScope.launch {
            val mood = moodRepository.getMoodForDate(getCurrentDate())
            _selectedMood.value = mood?.moodText ?: ""
        }
    }

    fun saveMood(moodText: String) {
        val mood = Mood(date = getCurrentDate(), moodText = moodText)
        viewModelScope.launch {
            moodRepository.addOrUpdateMood(mood)
            _selectedMood.value = moodText
        }
    }

    private fun getCurrentDate(): String {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
        return sdf.format(java.util.Date())
    }
}
