package com.devtwofaces.neuronest.di

import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.devtwofaces.neuronest.data.local.AppDatabase
import com.devtwofaces.neuronest.data.local.*
import com.devtwofaces.neuronest.data.repository.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "neuro_nest_db"
        )
        .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
        .build()
    }

    @Provides
    fun provideUserDao(db: AppDatabase): UserDao = db.userDao()

    @Provides
    fun provideDailyCheckInDao(db: AppDatabase): DailyCheckInDao = db.dailyCheckInDao()

    @Provides
    fun provideGoalDao(db: AppDatabase): GoalDao = db.goalDao()

    @Provides
    fun provideMedicationDao(db: AppDatabase): MedicationDao = db.medicationDao()

    @Provides
    fun provideMoodDao(db: AppDatabase): MoodDao = db.moodDao()

    @Provides
    fun provideTrendDao(db: AppDatabase): TrendDao = db.trendDao()

    @Provides
    @Singleton
    fun provideUserRepository(userDao: UserDao): UserRepository = UserRepository(userDao)

    @Provides
    fun provideDailyCheckInRepository(dao: DailyCheckInDao): DailyCheckInRepository = DailyCheckInRepository(dao)

    @Provides
    fun provideGoalRepository(dao: GoalDao): GoalRepository = GoalRepository(dao)

    @Provides
    fun provideMedicationRepository(dao: MedicationDao): MedicationRepository = MedicationRepository(dao)

    @Provides
    fun provideMoodRepository(dao: MoodDao): MoodRepository = MoodRepository(dao)

    @Provides
    fun provideTrendRepository(dailyCheckInDao: DailyCheckInDao, moodDao: MoodDao): TrendRepository = TrendRepository(dailyCheckInDao, moodDao)

    private val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE goals ADD COLUMN completed INTEGER NOT NULL DEFAULT 0")
        }
    }
    private val MIGRATION_2_3 = object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE moods ADD COLUMN date TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE goals ADD COLUMN date TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE medications ADD COLUMN date TEXT NOT NULL DEFAULT ''")
        }
    }

}
