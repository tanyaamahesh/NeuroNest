package com.devtwofaces.neuronest.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.devtwofaces.neuronest.data.repository.GoalRepository
import com.devtwofaces.neuronest.data.model.Goal
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class GoalViewModel @Inject constructor(
    private val repository: GoalRepository
) : ViewModel() {
    private val _goals = MutableStateFlow<List<Goal>>(emptyList())
    val goals: StateFlow<List<Goal>> = _goals

    init {
        fetchGoals()
    }

    private fun fetchGoals() {
        viewModelScope.launch {
            repository.getGoals().collect { listOfGoals ->
                _goals.value = listOfGoals
            }
        }
    }

    fun addGoal(goal: String) {
        val goalEntry = Goal(date = getCurrentDate(), goal = goal)
        viewModelScope.launch {
            repository.addGoal(goalEntry)
            fetchGoals()
        }
    }

    fun updateGoal(goal: Goal) {
        viewModelScope.launch {
            repository.updateGoal(goal)
            fetchGoals()
        }
    }

    fun deleteGoal(goal: Goal) {
        viewModelScope.launch {
            repository.deleteGoal(goal)
            fetchGoals()
        }
    }

    private fun getCurrentDate(): String {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
        return sdf.format(java.util.Date())
    }
}
