package com.devtwofaces.neuronest.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.devtwofaces.neuronest.viewmodel.MedicationViewModel

@Composable
fun AddMedicationScreen(navController: NavController, viewModel: MedicationViewModel = hiltViewModel()) {
    var searchQuery by remember { mutableStateOf(TextFieldValue("")) }
    val medications = listOf("Medication1", "Medication2", "Medication3") // Hardcoded list of medications

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "Add Medication",
                fontSize = 24.sp,
                modifier = Modifier
                    .weight(6f)
                    .padding(bottom = 16.dp, top = 20.dp)
            )
            Spacer(modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        SearchBar(
            searchQuery = searchQuery.text,
            onSearchQueryChanged = { searchQuery = TextFieldValue(it) },
            onClearSearchQuery = { searchQuery = TextFieldValue("") }
        )

        Spacer(modifier = Modifier.height(16.dp))

        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            medications.filter { it.contains(searchQuery.text, ignoreCase = true) }.forEach { medication ->
                Text(
                    text = medication,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .background(Color(0xFFEBD7F5), RoundedCornerShape(16.dp))
                        .clickable { navController.navigate("add_medication_details/$medication") }
                        .padding(16.dp)
                        .padding(start = 10.dp, end = 10.dp)
                )
            }
        }
    }
}


@Composable
fun SearchBar(searchQuery: String, onSearchQueryChanged: (String) -> Unit, onClearSearchQuery: () -> Unit) {
    TextField(
        value = searchQuery,
        onValueChange = onSearchQueryChanged,
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = Color.Black
            )
        },
        trailingIcon = {
            if (searchQuery.isNotEmpty()) {
                IconButton(onClick = onClearSearchQuery) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Clear Search",
                        tint = Color.Black
                    )
                }
            }
        },
        placeholder = { Text("Search Medication") },
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp) // Adjust the height as needed
            .padding(horizontal = 20.dp)
            .border(
                width = 1.dp,
                color = Color.Black,
                shape = RoundedCornerShape(12.dp) // Adjust the corner radius as needed
            ),
        colors = TextFieldDefaults.colors(
            unfocusedContainerColor = Color.White,
            focusedContainerColor = Color.White,
            unfocusedIndicatorColor = Color.Transparent,
            focusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent,
            errorIndicatorColor = Color.Transparent
        ),
        shape = RoundedCornerShape(12.dp) // Adjust the corner radius as needed
    )
}

