package com.devtwofaces.neuronest.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.devtwofaces.neuronest.data.model.Trend
import kotlinx.coroutines.flow.Flow


@Dao
interface TrendDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrend(trend: Trend)

    @Query("SELECT * FROM trends WHERE type = :type AND date BETWEEN :startDate AND :endDate")
    fun getTrends(type: String, startDate: String, endDate: String): Flow<List<Trend>>

    @Query("SELECT DISTINCT description FROM trends WHERE type = 'Symptom' AND date BETWEEN :startDate AND :endDate")
    fun getUniqueSymptoms(startDate: String, endDate: String): Flow<List<String>>

    @Query("SELECT date, moodText as mood FROM moods WHERE date BETWEEN :startDate AND :endDate")
    fun getFeelingsInRange(startDate: String, endDate: String): Flow<List<Feeling>>
}

data class Feeling(
    val date: String,
    val mood: String
)
