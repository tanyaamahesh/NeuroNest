package com.devtwofaces.neuronest.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.devtwofaces.neuronest.data.repository.MedicationRepository
import com.devtwofaces.neuronest.data.model.Medication
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MedicationViewModel @Inject constructor(
    private val repository: MedicationRepository
) : ViewModel() {
    private val _medications = MutableStateFlow<List<Medication>>(emptyList())
    val medications: StateFlow<List<Medication>> = _medications

    init {
        fetchMedications()
    }

    private fun fetchMedications() {
        viewModelScope.launch {
            repository.getMedications().collect { listOfMedications ->
                _medications.value = listOfMedications
            }
        }
    }

    fun addMedication(name: String, dosage: String, unit: String) {
        val medication = Medication(date = getCurrentDate(), name = name, dosage = dosage, unit = unit)
        viewModelScope.launch {
            repository.addMedication(medication)
            fetchMedications()
        }
    }

    fun deleteMedication(medication: Medication) {
        viewModelScope.launch {
            repository.deleteMedication(medication)
            fetchMedications()
        }
    }

    private fun getCurrentDate(): String {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
        return sdf.format(java.util.Date())
    }
}
