package com.devtwofaces.neuronest.data.repository

import com.devtwofaces.neuronest.data.local.UserDao
import com.devtwofaces.neuronest.data.model.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

class UserRepository @Inject constructor(
    private val userDao: UserDao
) {
    val user: StateFlow<User?> = userDao.getUser().stateIn(
        scope = CoroutineScope(Dispatchers.IO),
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    suspend fun getUser(): User? {
        return userDao.getUserOnce()
    }

    suspend fun saveUser(user: User) {
        userDao.insertUser(user)
    }
}


