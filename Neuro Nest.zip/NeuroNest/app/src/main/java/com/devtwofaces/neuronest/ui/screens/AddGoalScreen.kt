package com.devtwofaces.neuronest.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.devtwofaces.neuronest.viewmodel.GoalViewModel

@Composable
fun AddGoalScreen(navController: NavController, viewModel: GoalViewModel = hiltViewModel()) {
    var goalText by remember { mutableStateOf(TextFieldValue("")) }
    val context = LocalContext.current;

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "Add Goal",
                fontSize = 24.sp,
                modifier = Modifier
                    .weight(6f)
                    .padding(bottom = 16.dp, top = 20.dp)
            )
            Spacer(modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .height(250.dp)
                .border(BorderStroke(3.dp, color = Color(0x80C8B3E7)), shape = RoundedCornerShape(12.dp))
                .background(Color.White)
                .padding(16.dp)
        ) {
            BasicTextField(
                value = goalText,
                onValueChange = { goalText = it },
                modifier = Modifier.fillMaxSize().padding(14.dp),
                textStyle = TextStyle(color = Color.Black, fontSize = 17.sp),
                decorationBox = { innerTextField ->
                    if (goalText.text.isEmpty()) {
                        Text("Enter your goal...", color = Color.Gray, fontSize = 17.sp)
                    }
                    innerTextField()
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .padding(bottom = 2.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Button(
                onClick = {
                    if (goalText.text.isEmpty()) {
                        Toast.makeText(context, "Goal cannot be empty", Toast.LENGTH_SHORT).show()
                    } else {
                        viewModel.addGoal(goalText.text)
                        navController.navigate("my_day") {
                            popUpTo("my_day") { inclusive = true }
                        }
                    }
                },
                modifier = Modifier
                    .padding(horizontal = 18.dp, vertical = 20.dp)
                    .height(48.dp)
                    .fillMaxSize(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A3A69)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(text = "ADD GOAL", color = Color.White, fontSize = 18.sp)
            }
        }

    }
}
