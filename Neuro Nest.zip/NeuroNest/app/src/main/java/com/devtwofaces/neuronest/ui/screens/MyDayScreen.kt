package com.devtwofaces.neuronest.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.devtwofaces.neuronest.R
import com.devtwofaces.neuronest.data.model.Goal
import com.devtwofaces.neuronest.data.model.Medication
import com.devtwofaces.neuronest.ui.components.CustomScrollIndicator
import com.devtwofaces.neuronest.viewmodel.GoalViewModel
import com.devtwofaces.neuronest.viewmodel.MedicationViewModel
import com.devtwofaces.neuronest.viewmodel.MyDayViewModel
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.ui.text.TextStyle

@Composable
fun MyDayScreen(navController: NavController, viewModel: MyDayViewModel = hiltViewModel()) {
    val scrollState = rememberScrollState()
    val userName by viewModel.userName.collectAsState(initial = "NAME")

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .padding(top = 24.dp)
                .verticalScroll(scrollState)
        ) {
            Text(
                text = "Hello, $userName!",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(16.dp))

            DailyCheckInSection(navController)
            Spacer(modifier = Modifier.height(16.dp))

            TrendsSection(navController)
            Spacer(modifier = Modifier.height(16.dp))

            MedicationsSection(navController)
            Spacer(modifier = Modifier.height(16.dp))

            GoalsSection(navController)
            Spacer(modifier = Modifier.height(16.dp))

            MoodSection()
            Spacer(modifier = Modifier.height(16.dp))

            RecentlyLoggedItemsSection(navController)

            Spacer(modifier = Modifier.height(88.dp))
        }

        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopEnd) {
            CustomScrollIndicator(scrollState)
        }

        Box(modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .padding(bottom = 2.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Button(
                onClick = { navController.navigate("log_item") },
                modifier = Modifier
                    .padding(horizontal = 18.dp, vertical = 20.dp)
                    .height(48.dp)
                    .fillMaxSize(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A3A69)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(text = "LOG AN ITEM", color = Color.White, fontSize = 18.sp)
            }
        }

    }
}

@Composable
fun DailyCheckInSection(navController: NavController) {
    SectionContainer(
        headerText = "DAILY CHECK IN",
        headerStyle = TextStyle(color = Color(0xFF626669), fontSize = 20.sp, fontWeight = FontWeight.Bold)
    ){
        Box(
            modifier = Modifier
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.calendar_2),
                contentDescription = null,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Button(
                onClick = { navController.navigate("daily_check_in_step1") },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B6EB7)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(text = "CHECK-IN", color = Color.White)
            }
        }
    }
}

@Composable
fun TrendsSection(navController: NavController) {
    SectionContainer(
        headerText = "FROM YOUR WATCH",
        subHeaderText = "Recent Trends",
        headerStyle = TextStyle(color = Color(0xFF626669), fontSize = 20.sp, fontWeight = FontWeight.Bold)
    ) {
        TrendsChart()
        Spacer(modifier = Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Button(
                onClick = { navController.navigate("trends_screen") },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B6EB7)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(text = "VIEW TRENDS", color = Color.White)
            }
        }
    }
}



@Composable
fun TrendsChart() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(top = 10.dp)
    ) {
        Column {
                // Example of a custom chart view
            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.Bottom
            ) {
                val days = listOf("S", "M", "T", "W", "T", "F", "S")
                days.forEach { day ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .width(16.dp)
                                .height((50..150).random().dp)
                                .background(Color(0xFF8B6EB7))
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = day)
                    }
                }
            }
        }
    }
}


@Composable
fun MedicationsSection(navController: NavController, viewModel: MedicationViewModel = hiltViewModel()) {
    val medications by viewModel.medications.collectAsState()

    SectionContainer(
        headerText = "MEDICATION",
        headerStyle = TextStyle(color = Color(0xFF626669), fontSize = 20.sp, fontWeight = FontWeight.Bold),
        actionButton = {
            IconButton(onClick = { navController.navigate("add_medication") }) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_add),
                    contentDescription = "Add Medication",
                    tint = Color.Gray
                )
            }
        }
    ) {
        Column {
            medications.forEach { medication ->
                MedicationItem(medication = medication, onDelete = { viewModel.deleteMedication(medication) })
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Button(
                onClick = { /* Navigate to Medications screen */ },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B6EB7)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(text = "VIEW TODAY'S SCHEDULE", color = Color.White)
            }
        }
    }
}

@Composable
fun GoalsSection(navController: NavController, viewModel: GoalViewModel = hiltViewModel()) {
    val goals by viewModel.goals.collectAsState()

    SectionContainer(
        headerText = "TODAY'S GOALS",
        headerStyle = TextStyle(color = Color(0xFF626669), fontSize = 20.sp, fontWeight = FontWeight.Bold),
        actionButton = {
            IconButton(onClick = { navController.navigate("add_goal") }) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_add),
                    contentDescription = "Add Goal",
                    tint = Color.Gray
                )
            }
        }
    ) {
        Column {
            goals.forEach { goal ->
                GoalItem(
                    goal = goal,
                    onCheckedChange = { updatedGoal ->
                        viewModel.updateGoal(updatedGoal)
                    },
                    onDelete = {
                        viewModel.deleteGoal(goal)
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MoodSection(viewModel: MyDayViewModel = hiltViewModel()) {
    val selectedMood by viewModel.selectedMood.collectAsState()

    SectionContainer(
        headerText = "HOW ARE YOU?",
        headerStyle = TextStyle(color = Color(0xFF626669), fontSize = 20.sp, fontWeight = FontWeight.Bold)
    ) {
        FlowRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val moods = listOf("AWFUL", "BAD", "OKAY", "GOOD", "GREAT")
            moods.forEach { mood ->
                MoodButton(
                    text = mood,
                    isSelected = selectedMood == mood,
                    onClick = { viewModel.saveMood(mood) }
                )
            }
        }
    }
}

@Composable
fun MoodButton(text: String, isSelected: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .wrapContentWidth()
            .wrapContentHeight(),
        colors = ButtonDefaults.buttonColors(containerColor = if (isSelected) Color(0xFF8B6EB7) else Color(0xB2AEA8B6)),
        shape = RoundedCornerShape(24.dp)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 12.sp,
            maxLines = 1,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
    }
}

@Composable
fun RecentlyLoggedItemsSection(navController: NavController) {
    Card(
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(3.dp, color = Color(0x80C8B3E7)),
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "RECENTLY LOGGED ITEMS",
                style = TextStyle(color = Color(0xFF626669), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            )
            Icon(
                painter = painterResource(id = R.drawable.ic_right),
                contentDescription = null,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}


@Composable
fun SectionContainer(
    headerText: String,
    headerStyle: TextStyle = TextStyle.Default.copy(color = Color.Black, fontSize = 20.sp, fontWeight = FontWeight.Bold),
    subHeaderText: String? = null,
    actionButton: @Composable (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(3.dp, color = Color(0x80C8B3E7)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = headerText,
                        style = headerStyle
                    )
                    subHeaderText?.let {
                        Text(text = it, style = MaterialTheme.typography.titleMedium)
                    }
                }
                actionButton?.invoke()
            }
            Spacer(modifier = Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
fun MedicationItem(medication: Medication, onDelete: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .background(Color(0x19803B80), RoundedCornerShape(4.dp))
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = medication.name,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier
                    .padding(bottom = 2.dp)
                    .padding(horizontal = 4.dp)
            )
            Text(
                text = "${medication.dosage} ${medication.unit}",
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                modifier = Modifier
                    .padding(top = 2.dp)
                    .padding(horizontal = 4.dp)
            )
        }
        IconButton(onClick = onDelete) {
            Icon(painter = painterResource(id = R.drawable.ic_delete), contentDescription = "Delete")
        }
    }
}

@Composable
fun GoalItem(goal: Goal, onCheckedChange: (Goal) -> Unit, onDelete: () -> Unit) {
    val isChecked = remember { mutableStateOf(goal.completed) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .background(Color(0x19803B80), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = isChecked.value,
                onCheckedChange = {
                    isChecked.value = it
                    onCheckedChange(goal.copy(completed = it))
                },
                colors = CheckboxDefaults.colors(
                    checkedColor = Color(0xFF555555),
                    uncheckedColor = Color(0xD3555555),
                    checkmarkColor = Color.White
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = goal.goal,
                style = MaterialTheme.typography.bodyLarge
            )
        }
        IconButton(onClick = onDelete) {
            Icon(
                painter = painterResource(id = R.drawable.ic_delete),
                contentDescription = "Delete Goal"
            )
        }
    }
}

@Composable
fun LogAnItemScreen(navController: NavController) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = "Log An Item",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(vertical = 32.dp)
        )

        // List of loggable items
        val items = listOf(
            "Symptom or Side Effect",
            "Medication or Supplement",
            "Influence (food, sleep, etc)",
            "Note",
            "Drawing Test",
            "Finger Tapping Test"
        )

        items.forEach { item ->
            LoggableItemCard(item = item, navController = navController)
            Spacer(modifier = Modifier.height(20.dp))
        }

        Spacer(modifier = Modifier.weight(1f))
    }

    Box(modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 24.dp)
        .padding(bottom = 2.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        Button(
            onClick = { navController.navigate("add_goal") },
            modifier = Modifier
                .padding(horizontal = 18.dp, vertical = 20.dp)
                .height(48.dp)
                .fillMaxSize(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A3A69)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(text = "ADD GOAL", color = Color.White, fontSize = 18.sp)
        }
    }
}

@Composable
fun LoggableItemCard(item: String, navController: NavController) {
    Card(
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(3.dp, color = Color(0x80C8B3E7)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 26.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = item,
                style = TextStyle(color = Color(0xFF8B6EB7), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            )
            Icon(
                painter = painterResource(id = R.drawable.ic_right),
                contentDescription = "Navigate",
                tint = Color(0xFF8B6EB7),
                modifier = Modifier.size(30.dp)
            )
        }
    }
}

