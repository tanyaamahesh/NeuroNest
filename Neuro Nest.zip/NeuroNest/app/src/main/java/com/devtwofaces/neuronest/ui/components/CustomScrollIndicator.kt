package com.devtwofaces.neuronest.ui.components

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp

@Composable
fun CustomScrollIndicator(scrollState: ScrollState) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxHeight()
    ) {
        val boxHeight = constraints.maxHeight.toFloat()
        val scrollProgress = scrollState.value.toFloat() / scrollState.maxValue.toFloat()
        val indicatorHeightPx = with(LocalDensity.current) { 120.dp.toPx() } // Set the height of the indicator
        val indicatorOffsetPx = scrollProgress * (boxHeight - indicatorHeightPx)
        val indicatorOffset = with(LocalDensity.current) { indicatorOffsetPx.toDp() }

        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(14.dp)
                .padding(vertical = 16.dp)
                .background(Color.Transparent)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .offset(y = indicatorOffset)
                    .background(
                        color = Color.Black.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(topStart = 50.dp, bottomStart = 50.dp)
                    )
            )
        }
    }
}
