package com.devtwofaces.neuronest.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.devtwofaces.neuronest.data.model.Mood
import kotlinx.coroutines.flow.Flow

@Dao
interface MoodDao {
    @Query("SELECT * FROM moods")
    fun getMoods(): Flow<List<Mood>>

    @Query("SELECT * FROM moods WHERE date = :date LIMIT 1")
    suspend fun getMoodForDate(date: String): Mood?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(mood: Mood)

    @Update
    suspend fun update(mood: Mood)

    @Query("SELECT * FROM moods WHERE date BETWEEN :startDate AND :endDate")
    fun getMoodsInRange(startDate: String, endDate: String): Flow<List<Mood>>
}
