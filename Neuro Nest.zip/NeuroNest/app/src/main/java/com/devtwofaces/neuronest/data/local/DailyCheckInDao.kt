package com.devtwofaces.neuronest.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.devtwofaces.neuronest.data.model.DailyCheckIn
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyCheckInDao {
    @Query("SELECT * FROM daily_check_ins WHERE date = :date LIMIT 1")
    suspend fun getCheckInByDate(date: String): DailyCheckIn?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyCheckIn(checkIn: DailyCheckIn)

    @Update
    suspend fun updateDailyCheckIn(checkIn: DailyCheckIn)

    @Query("SELECT DISTINCT symptoms FROM daily_check_ins WHERE date BETWEEN :startDate AND :endDate")
    fun getUniqueSymptoms(startDate: String, endDate: String): Flow<List<String>>
}
